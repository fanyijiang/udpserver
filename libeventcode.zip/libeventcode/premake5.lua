-- premake5.lua
workspace "Libevent"
   location "Libevent"
   configurations { "Release" }
   platforms { "x64" }
   characterset "ASCII"
   
project "event"
   symbolspath 'Game/$(Configuration)_$(Platform)/symbols/$(TargetName).pdb'
   symbols "On"
   links { "ws2_32.lib" }
   defines { "WIN32","HAVE_CONFIG_H" }
   kind "ConsoleApp"
   location "libevent"
   language "C++"
   includedirs { "WIN32-Code/","include/","compat/","./"}
   targetdir "Game/$(Configuration)_$(Platform)"
   objdir "!vsobj/$(Configuration)_$(Platform)"
   buildlog ("Game/build/$(MSBuildProjectName).log")
   flags { "NoBufferSecurityCheck" }
   files { "**.h", "**.c"}
   removefiles { "arc4random.c","devpoll.c","epoll_sub.c","epoll.c","evport.c","kqueue.c","bufferevent_openssl.c","poll.c","evthread_pthread.c","select.c","test/**","sample/hello-world.c","sample/dns-example.c","sample/event-test.c","sample/http-server.c","sample/le-proxy.c","sample/signal-test.c","sample/time-test.c"}
   --removefiles { "devpoll.c","epoll_sub.c","epoll.c","evport.c","kqueue.c","bufferevent_openssl.c","poll.c","evthread_pthread.c","select.c", "sample/le-proxy.c","sample/signal-test.c"}
   filter "configurations:Release"
      optimize "Full"
	  architecture "x86_64"
	  
