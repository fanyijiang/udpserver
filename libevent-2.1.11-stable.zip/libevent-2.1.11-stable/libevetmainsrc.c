#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <event.h>
#include <event2/listener.h>
#include <Windows.h>
#define SVR_IP "192.168.20.200"
#define SVR_PORT 10000
#define BUF_SIZE 1024


void read_cb(int fd, short events, void *arg) {
	char buf[BUF_SIZE];
	int len;
	struct event *ev;
	int size = sizeof(struct sockaddr);
	struct sockaddr_in client_addr;
	memset(buf, 0, sizeof(buf));
	ev= (arg);
	len = recvfrom(fd, buf, sizeof(buf), 0, (struct sockaddr *)&client_addr, &size);
	printf("recvfrom: len [%d] event[%d]  ev_events[%d]\n", len,events,ev->ev_events);
	if (ev->ev_events &  EV_READ) 
	{
		printf("recvfrom:  read \n");
	}
	if (len == -1) {
		perror("recvfrom()");
	} else if (len == 0) {
		printf("Connection Closed\n");
	} else {
		printf("Read: len [%d] �C content [%s]\n", len, buf);

		/* Echo */
		sendto(fd, buf, len, 0, (struct sockaddr *)&client_addr, size);
	}
}



int bind_socket(struct event *ev) {
	int sock_fd;
	int flag = 1;
	struct sockaddr_in sin;

	/* Create endpoint */
	if ((sock_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		perror("socket()");
		return -1;
	}

	/* Set socket option */
	if (setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(int)) < 0) {
		perror("setsockopt()");
		return 1;
	}

	/* Set IP, port */
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = inet_addr(SVR_IP);
	sin.sin_port = htons(SVR_PORT);

	/* Bind */
	if (bind(sock_fd, (struct sockaddr *)&sin, sizeof(struct sockaddr)) < 0) {
		perror("bind()");
		return -1;
	} else {
		printf("bind() success �C [%s] [%u]\n", SVR_IP, SVR_PORT);
	}

	/* Init one event and add to active events */
	event_set(ev, sock_fd,  EV_PERSIST|EV_READ , &read_cb, ev);
	if (event_add(ev, NULL) == -1) {
		printf("event_add() failed\n");
	}

	return 0;
}


int main(int argc,char **argv)
{

	struct event ev;
	WSADATA wsd;
	int i=0;
	int iRet = 0;
	const char **support;
	printf("test hello world come in \n");

	//SSIZE_T t;

	// ��ʼ���׽��ֶ�̬��
	if(WSAStartup(MAKEWORD(2,2), &wsd)!= 0){
		printf("WSAStartup failed:%d!\n", WSAGetLastError());
		return -1;
	}
	support=event_get_supported_methods();
	printf("libevent support backend methods:");
	for(i=0;support[i]!=NULL;++i){
		printf("%s\t",support[i]);
	}
	printf("\n");

	/* Init. event */
	if (event_init() == NULL) {
		printf("event_init() failed\n");
		return -1;
	}

	/* Bind socket */
	if (bind_socket(&ev) != 0) {
		printf("bind_socket() failed\n");
		return -1;
	}

	/* Enter event loop */
	event_dispatch();

	system("Pause");
}